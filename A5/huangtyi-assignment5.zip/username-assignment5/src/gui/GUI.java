package gui;

import filters.EdgeHighlightFilter;
import filters.FlipHorizontalFilter;
import filters.FlipVerticalFilter;
import filters.GrayscaleFilter;
import filters.SharpenFilter;
import filters.SoftenFilter;
import filters.Filter;
import image.PixelImage;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JFileChooser;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JOptionPane;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

/**
 * GUI class for Image Filter Program.
 *
 * @author Tianyi Huang
 * @version 11/08/2024
 */
public class GUI extends JFrame {
    /**
     * UID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * row of button panel.
     */
    private static final int BUTTON_PANEL_ROW = 6;

    /**
     * col of button panel.
     */
    private static final int BUTTON_PANEL_COL = 1;

    /**
     * icon of title.
     */
    private static final String ICON_TITLE = "icons/w.gif";

    /**
     * icon of open.
     */
    private static final String ICON_OPEN = "icons/open.gif";

    /**
     * icon of save.
     */
    private static final String ICON_SAVE = "icons/save.gif";

    /**
     * icon of close.
     */
    private static final String ICON_CLOSE = "icons/close.gif";

    /**
     * save button.
     */
    private JButton mySaveButton;

    /**
     * close button.
     */
    private JButton myCloseButton;

    /**
     * edgeHighlight button.
     */
    private JButton myEdgeHighlightButton;

    /**
     * flipHorizontal button.
     */
    private JButton myFlipHorizontalButton;

    /**
     * flipVertical button.
     */
    private JButton myFlipVerticalButton;

    /**
     * grayscale button.
     */
    private JButton myGrayscaleButton;

    /**
     * sharpen button.
     */
    private JButton mySharpenButton;

    /**
     * soften button.
     */
    private JButton mySoftenButton;

    /**
     * edgeHighlight filter.
     */
    private final EdgeHighlightFilter myEdgeHighlightFilter;

    /**
     * flipHorizontal filter.
     */
    private final FlipHorizontalFilter myFlipHorizontalFilter;

    /**
     * flipVertical filter.
     */
    private final FlipVerticalFilter myFlipVerticalFilter;

    /**
     * grayscale filter.
     */
    private final GrayscaleFilter myGrayscaleFilter;

    /**
     * sharpen filter.
     */
    private final SharpenFilter mySharpenFilter;

    /**
     * soften filter.
     */
    private final SoftenFilter mySoftenFilter;

    /**
     * image label.
     */
    private JLabel myImageLabel;

    /**
     * file chooser.
     */
    private final JFileChooser myFileChooser;

    /**
     * current image.
     */
    private PixelImage myCurrentImage;

    /**
     * Constructs a GUI for the image filter program.
     */
    public GUI() {
        setTitle("TCSS 305 - Image Filter Program");
        setIconImage(new ImageIcon(ICON_TITLE).getImage());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        myEdgeHighlightFilter = new EdgeHighlightFilter();
        myFlipHorizontalFilter = new FlipHorizontalFilter();
        myFlipVerticalFilter = new FlipVerticalFilter();
        myGrayscaleFilter = new GrayscaleFilter();
        mySharpenFilter = new SharpenFilter();
        mySoftenFilter = new SoftenFilter();

        myFileChooser = new JFileChooser();
    }

    /**
     * Starts the GUI and sets up the components.
     */
    public void start() {
        myFileChooser.setCurrentDirectory(new File(System.getProperty("user.dir")));

        // buttons
        final JButton openButton = createButton("Open...", new ImageIcon(ICON_OPEN),
                this::openImage);
        mySaveButton = createButton("Save As...", new ImageIcon(ICON_SAVE),
                this::saveImage);
        myCloseButton = createButton("Close Image", new ImageIcon(ICON_CLOSE),
                this::closeImage);

        myEdgeHighlightButton = createFilterButton(myEdgeHighlightFilter.getDescription(),
                e -> applyFilter(myEdgeHighlightFilter));
        myFlipHorizontalButton = createFilterButton(myFlipHorizontalFilter.getDescription(),
                e -> applyFilter(myFlipHorizontalFilter));
        myFlipVerticalButton = createFilterButton(myFlipVerticalFilter.getDescription(),
                e -> applyFilter(myFlipVerticalFilter));
        myGrayscaleButton = createFilterButton(myGrayscaleFilter.getDescription(),
                e -> applyFilter(myGrayscaleFilter));
        mySharpenButton = createFilterButton(mySharpenFilter.getDescription(),
                e -> applyFilter(mySharpenFilter));
        mySoftenButton = createFilterButton(mySoftenFilter.getDescription(),
                e -> applyFilter(mySoftenFilter));

        // layout
        final JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(BUTTON_PANEL_ROW, BUTTON_PANEL_COL));
        buttonPanel.add(myEdgeHighlightButton);
        buttonPanel.add(myFlipHorizontalButton);
        buttonPanel.add(myFlipVerticalButton);
        buttonPanel.add(myGrayscaleButton);
        buttonPanel.add(mySharpenButton);
        buttonPanel.add(mySoftenButton);

        final JPanel bottomPanel = new JPanel();
        bottomPanel.add(openButton);
        bottomPanel.add(mySaveButton);
        bottomPanel.add(myCloseButton);

        myImageLabel = new JLabel();
        myImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        myImageLabel.setVerticalAlignment(SwingConstants.CENTER);

        // add panels
        add(buttonPanel, BorderLayout.WEST);
        add(myImageLabel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        setButtonsEnabled(false);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * Creates a button with specified text, icon, and action listener.
     *
     * @param theText the text to display on the button
     * @param theIcon the icon to display on the button
     * @param theAction the action listener to handle button clicks
     * @return the created JButton
     */
    private JButton createButton(final String theText, final ImageIcon theIcon,
                                 final ActionListener theAction) {
        final JButton button = new JButton(theText, theIcon);
        button.addActionListener(theAction);
        return button;
    }

    /**
     * Creates a filter button that is initially disabled.
     *
     * @param theText the text to display on the button
     * @param theAction the action listener to handle button clicks
     * @return the created JButton
     */
    private JButton createFilterButton(final String theText, final ActionListener theAction) {
        final JButton button = createButton(theText, null, theAction);
        button.setEnabled(false);
        return button;
    }

    /**
     * Opens an image file and displays it in the GUI.
     *
     * @param theAction actionEvent
     */
    private void openImage(final ActionEvent theAction) {
        final int returnValue = myFileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            final File file = myFileChooser.getSelectedFile();
            try {
                myCurrentImage = PixelImage.load(file);
                myImageLabel.setIcon(new ImageIcon(myCurrentImage));
                setButtonsEnabled(true);
                pack();
            } catch (final IOException ex) {
                showError("The selected File did not contain an image!");
            }
        }
    }

    /**
     * Saves the currently displayed image to a file.
     *
     * @param theAction actionEvent
     */
    private void saveImage(final ActionEvent theAction) {
        final int returnValue = myFileChooser.showSaveDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            final File file = myFileChooser.getSelectedFile();

            // check if the file already exists
            if (file.exists()) {
                final int confirm = JOptionPane.showConfirmDialog(this,
                        "The file already exists. Do you want to overwrite it?",
                        "Confirm",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);
                if (confirm != JOptionPane.YES_OPTION) {
                    return;
                }
            }

            try {
                myCurrentImage.save(file);
            } catch (final IOException ex) {
                showError("Failed to save image.");
            }
        }
    }

    /**
     * Closes the currently displayed image and resets the GUI.
     *
     * @param theAction actionEvent
     */
    private void closeImage(final ActionEvent theAction) {
        myCurrentImage = null;
        myImageLabel.setIcon(null);
        setButtonsEnabled(false);
        pack();
    }

    /**
     * Applies the specified filter to the current image and updates the display.
     *
     * @param theFilter filter
     */
    private void applyFilter(final Filter theFilter) {
        if (myCurrentImage != null) {
            theFilter.filter(myCurrentImage);
            myImageLabel.setIcon(new ImageIcon(myCurrentImage));
        }
    }

    /**
     * Enables or disables filter and save buttons based on the current image status.
     *
     * @param theStatus true or false
     */
    private void setButtonsEnabled(final boolean theStatus) {
        myEdgeHighlightButton.setEnabled(theStatus);
        myFlipHorizontalButton.setEnabled(theStatus);
        myFlipVerticalButton.setEnabled(theStatus);
        myGrayscaleButton.setEnabled(theStatus);
        mySharpenButton.setEnabled(theStatus);
        mySoftenButton.setEnabled(theStatus);
        mySaveButton.setEnabled(theStatus);
        myCloseButton.setEnabled(theStatus);
    }

    /**
     * Displays an error message in a dialog box.
     *
     * @param theMessage the error message to display
     */
    private void showError(final String theMessage) {
        JOptionPane.showMessageDialog(this, theMessage, "Error", JOptionPane.ERROR_MESSAGE);
    }
}